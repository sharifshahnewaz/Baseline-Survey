﻿namespace ReportsApplication1 {
    
    
    public partial class DataSet {
        partial class UnionDataTable
        {
        }
    }
}
