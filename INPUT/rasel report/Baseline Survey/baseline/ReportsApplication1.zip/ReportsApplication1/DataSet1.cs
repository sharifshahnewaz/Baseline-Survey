﻿namespace ReportsApplication1 {
    
    
    public partial class DataSet1 {
        partial class UnionDataTable
        {
        }
    }
}
