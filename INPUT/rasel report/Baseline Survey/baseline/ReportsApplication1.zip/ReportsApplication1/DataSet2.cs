﻿namespace ReportsApplication1 {
    
    
    public partial class DataSet2 {
        partial class DataTable1DataTable
        {
        }
    
        partial class Table12DataTable
        {
        }

        partial class Table10DataTable
        {
        }
    
        partial class Table7DataTable
        {
        }
    
        partial class Table_3DataTable
        {
        }
    }
}

namespace ReportsApplication1.DataSet2TableAdapters {
    
    
    public partial class Table13BTableAdapter {
    }
}
